# Autism_detection

Check out the blog post : https://medium.com/@aparnashankar004/autism-detection-from-brain-mri-and-screening-data-a-cloud-based-machine-learning-approach-5549d582ad45
